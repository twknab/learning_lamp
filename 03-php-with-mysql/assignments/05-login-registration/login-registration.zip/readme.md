# About:
This project involves using PHP to build out a login and registration, from scratch. No frameworks, just pure PHP, HTML, CSS and MySQL. The encryption method for storing user passwords, involves using md5 and a generated salt, to create a hash string. It should be warned that this particular encryption method should not be used for production purposes. But for learning purposes, and the aim of keeping things pure, it was a good learning experience to encrypt this way. (Challenge: come back later and change up encryption methods).


## Bug:
When you go small mobile, the CSS Grid seems to hit some issues w/ the form input fields overlapping screen. Maybe review some old CSS Grid material and see if you can figure out a fix.